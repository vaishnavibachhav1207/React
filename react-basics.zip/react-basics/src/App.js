import './App.css';
import FunctionalComponent from './components/FunctionalComponent';
import ClassComponent from './components/ClassComponent';
import State from './components/State';
import SetState from './components/SetState';
import FunctionalEventHandler from './components/FunctionalEventHandler';
import ClassEventHandler from './components/ClassEventHandler';
import EventBind from './components/EventBind';
import ParentComponent from './components/ParentComponent';
import ConditionalRendering from './components/ConditionalRendering';
import List from './components/List';
import FormHandling from './components/FormHandling';
import Fragments from './components/Fragments';
import PureComp from './components/PureComp';

function App() {
  return (
    <div className="App">
      {/* <FunctionalComponent name="Pratik Sehajpal" id="1">
        <p>lorem ipsum</p>
      </FunctionalComponent> */}
      {/* <FunctionalComponent name="Umar Riaz" id="2"/>
        <button>superman</button> */}
      {/* <ClassComponent name="Shehnaaz Gill" id="1"/> */}
      {/* <State></State> */}
      {/* <SetState></SetState> */}
      {/* <FunctionalEventHandler></FunctionalEventHandler> */}
      {/* <ClassEventHandler></ClassEventHandler> */}
      {/* <EventBind></EventBind> */}
      {/* <ParentComponent></ParentComponent> */}
      {/* <ConditionalRendering></ConditionalRendering> */}
      {/* <List></List> */}
      {/* <FormHandling></FormHandling> */}
      {/* <Fragments></Fragments> */}
      <PureComp></PureComp>
    </div>
  );
}

export default App;
