import React, { Component } from "react";

class State extends Component {
  constructor(){
    super();
    this.state = {
      message : "Welcome Visitor",
      count :0
    };
  }

  changeMessage(){
    this.setState({
        message : "Thank you for subscribing",
        count: 0
    });
  }

  render() {
    let {message , count} = this.state
    return (
      <div>
        <h1>{message}</h1>
        <h1>{count}</h1>
        <button onClick={()=> this.changeMessage()}>SUBSCRIBE</button>
      </div>
    )
  }
}

export default State;