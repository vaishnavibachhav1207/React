import React, { Component } from 'react';

class EventBind extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       message : 'Event Binding'
    }

    //this.clickHandler = this.clickHandler.bind(this);
  }
  
  // clickHandler(){
  //   this.setState({
  //     message : "Event Binding Methods"
  //   });
  // }

  // Using Arrow Functions
  clickHandler = () => {
    this.setState({
          message : "Event Binding Methods"
        });
    }

  render() {
    return (<div>
      <h1>{this.state.message}</h1>
        {/* <button onClick={this.clickHandler.bind(this)}>Binding in Render Method</button> */}
        {/* <button onClick={()=> this.clickHandler()}>Arrow function approach</button> */}
        <button onClick={this.clickHandler}>Binding in Constructor Method</button>
    </div>);
  }
}

export default EventBind;
