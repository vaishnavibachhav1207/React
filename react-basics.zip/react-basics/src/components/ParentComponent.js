import React, { Component } from 'react';
import ChildComponent from './ChildComponent';

class ParentComponent extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       parent : "Methods as props"
    }

    this.functionInParent = this.functionInParent.bind(this);
  }
  
  functionInParent(childName){
    alert(`Value ${this.state.parent} ${childName}`);
  }

  render() {
    return (<div>
        <ChildComponent greetHandler = {this.functionInParent}></ChildComponent>
    </div>);
  }
}

export default ParentComponent;
