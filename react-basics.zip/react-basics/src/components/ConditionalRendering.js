import React, { Component } from 'react';

class ConditionalRendering extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       isLoggedIn : true
    }
  }

  render() {
      // if(this.state.isLoggedIn){
      //   return <div><h2>Welcome Vaishnavi</h2></div>
      // }
      // else{
      //   return <div><h2>Welcome Guest</h2></div>
      // }

      // let message;
      // if(this.state.isLoggedIn){
      //   message = <div><h2>Welcome Vaishnavi</h2></div>
      // }
      // else{
      //   message = <div><h2>Welcome Guest</h2></div>
      // }

      // return <div>{message}</div>

      // return (
      //   this.state.isLoggedIn ? 
      //   <div><h2>Welcome Vaishnavi</h2></div> : 
      //   <div><h2>Welcome Guest</h2></div>
      // )

      return this.state.isLoggedIn && <div>Short Circuit Operator</div>
  }
}

export default ConditionalRendering;
