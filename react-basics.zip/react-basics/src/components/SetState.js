import React, { Component } from 'react';

class SetState extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       count :0 
    }
  }
  
  increment(){
    // this.setState({
    //   count : this.state.count + 1
    // },
    // () => {
    //   console.log("callback", this.state.count);
    // }
    // );
    this.setState((prevState1)=> ({
      count : prevState1.count + 1
    }));
  }

  incrementFive(){
    this.increment()
    this.increment()
    this.increment()  
    this.increment()  
    this.increment()  
  }

  render() {
    return (
      <div>
        <button onClick={() => this.incrementFive()}>Click</button>
        {this.state.count}
      </div>
    );
  }
}

export default SetState;