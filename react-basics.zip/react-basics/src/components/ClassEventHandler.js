import React, { Component } from 'react';

class ClassEventHandler extends Component {
  clickHandler(){
    console.log("hi");
  }
  render() {
    return (<div>
      <button onClick={this.clickHandler}>Click Me</button>
    </div>);
  }
}

export default ClassEventHandler;
