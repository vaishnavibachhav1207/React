import React from "react";

// function Greet(){
//   return <h1>Functional Components</h1>
// }

// const FunctionalComponent = (props) => {
//   return (
//     <div>
//       <h1>{props.name} {props.id}</h1>
//       {props.children}
//     </div>
//   )
// }

// Destructuring props - Way 1
// const FunctionalComponent = ({name, id, children}) => {
//   return (
//     <div>
//       <h1>{name} {id}</h1>
//       {children}
//     </div>
//   )
// }

// Destructuring props - Way 2
const FunctionalComponent = (props) => {
  const {name, id, children} = props;
  return (
    <div>
      <h1>{name} {id}</h1>
      {children}
    </div>
  )
}

export default FunctionalComponent;