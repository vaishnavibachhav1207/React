import React, { PureComponent } from 'react'

class PureComp extends PureComponent {
  render() {
    return (
      <div>PureComp</div>
    )
  }
}

export default PureComp