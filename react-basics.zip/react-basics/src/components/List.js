import React from 'react'
import Person from './Person';

function List() {

  const persons = [
    {
      id:1,
      name:'Vaishnavi',
      age:20,
      skill:'Developer'
    },
    {
      id:2,
      name:'Saleem',
      age:20,
      skill:'Team Lead'
    },
    {
      id:3,
      name:'Ronak',
      age:20,
      skill:'Developer'
    }
  ]
  const personsList = persons.map((person,index) => <Person key = {index} person = {person}></Person>)
  return (
    <div>
      {
        personsList
      }
    </div>
  )
}

export default List