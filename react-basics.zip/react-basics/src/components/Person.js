import React from 'react'

function Person({person}) {
  return (
    <div><h2>I am {person.name} working as a {person.skill}</h2></div>
  )
}

export default Person