import React from 'react'

function Fragments() {
  return (
    <>
      {/* <React.Fragment> */}
      <h1>React Fragment Demo</h1>
      <p>lorem dshfksjdhfkjsdhfkjsdhfkjsdhf
        sdfsdfsjdhfjsdfa-flip-horizontal hjhfsd hfksjdhfs jhfjsdf kjhfjsbdfhfss hskjdfhs
      </p>
    {/* </React.Fragment> */}
    </>
  )
}

export default Fragments