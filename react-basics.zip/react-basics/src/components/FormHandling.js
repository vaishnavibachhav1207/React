import React, { Component } from 'react'

class FormHandling extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       username : '',
       comments : '',
       topic: '1'
    }
  }
  
  handleUsernameChange = (event) => {
    this.setState({
      username: event.target.value
    });
  }

  handleCommentsChange = (event) => {
    this.setState({
      comments : event.target.value
    });
  }

  handleTopicChange = (event) => {
    this.setState({
      topic : event.target.value
    });
  }

  handleSubmit = (event) => {
    event.preventDefault();
    console.log(this.state.username);
    console.log(this.state.topic);
    console.log(this.state.comments);
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
          <label>Username</label>
          <input type="text" value={this.state.username} onChange={this.handleUsernameChange}/>
        </div>
        <div>
          <label>Comments</label>
          <textarea value={this.state.comments} onChange={this.handleCommentsChange}></textarea>
        </div>
        <div>
          <label>Topic</label>
          <select value={this.state.topic} onChange={this.handleTopicChange}>
            <option value="1">React</option>
            <option value="2">Angular</option>
            <option value="3">Vue</option>
          </select>
        </div>
        <button type="submit">Submit</button>
      </form>
    )
  }
}

export default FormHandling