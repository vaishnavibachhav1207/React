import React from "react";

function FunctionalEventHandler() {
  function clickHandler() {
    console.log("hi");
  }

  return (
    <div>
      <button onClick={clickHandler}>React events</button>
    </div>
  );
}

export default FunctionalEventHandler;
